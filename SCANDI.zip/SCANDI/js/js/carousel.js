$(document).ready(function() {
    $('.review__main-slide').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplaySpeed: 3000,
    });
})